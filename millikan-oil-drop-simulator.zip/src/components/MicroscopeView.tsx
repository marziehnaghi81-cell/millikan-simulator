import React, { useRef, useEffect } from "react";
import { Droplet } from "../types";

interface MicroscopeViewProps {
  droplets: Droplet[];
  selectedId: number | null;
  focusLevel: number;
  onSelectDroplet: (id: number) => void;
  scaleSDivs: number; // number of divisions (e.g., 5)
}

export default function MicroscopeView({
  droplets,
  selectedId,
  focusLevel,
  onSelectDroplet,
  scaleSDivs,
}: MicroscopeViewProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Height of the chamber simulated as 1.6mm (since PLATE_DISTANCE_D = 1.6mm).
  // The microscope visible vertical range is from 0.25mm to 1.25mm (span of 1.0mm).
  // Inverted optical system: Physical Y of 0.25mm (bottom-ish) is shown at the TOP of the reticle (line 0).
  // Physical Y of 1.25mm (top-ish) is shown at the BOTTOM of the reticle (line 10).
  const viewportMinY = 0.25; 
  const viewportHeight = 1.0; 

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, 400, 400);

    // Save state for clipping
    ctx.save();

    // 1. Draw circular microscope aperture limit
    ctx.beginPath();
    ctx.arc(200, 200, 180, 0, 2 * Math.PI);
    ctx.clip();

    // Dark slate background representing high-vacuum dark room environment
    ctx.fillStyle = "#020617";
    ctx.fillRect(0, 0, 400, 400);

    // Chamber glowing golden light emission (backlight)
    const radialGlow = ctx.createRadialGradient(200, 200, 10, 200, 200, 180);
    radialGlow.addColorStop(0, "rgba(245, 158, 11, 0.08)");
    radialGlow.addColorStop(0.5, "rgba(245, 158, 11, 0.02)");
    radialGlow.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = radialGlow;
    ctx.fillRect(0, 0, 400, 400);

    // 2. Draw measurement boundary shaded guides behind droplets
    const startDivIdx = 5 - Math.floor(scaleSDivs / 2);
    const endDivIdx = 5 + Math.ceil(scaleSDivs / 2);
    const startY = 40 + startDivIdx * 32;
    const endY = 40 + endDivIdx * 32;

    if (scaleSDivs > 0) {
      ctx.fillStyle = "rgba(59, 130, 246, 0.035)";
      ctx.fillRect(40, startY, 320, endY - startY);
    }

    // 3. Draw horizontal grid line markings (0 to 10 divisions, spaced by 32px each)
    for (let idx = 0; idx <= 10; idx++) {
      const yLine = 40 + idx * 32;
      const isCenter = idx === 5;
      const isBoundary = idx === startDivIdx || idx === endDivIdx;

      ctx.beginPath();
      ctx.moveTo(50, yLine);
      ctx.lineTo(350, yLine);

      if (isCenter) {
        ctx.strokeStyle = "rgba(245, 158, 11, 0.75)";
        ctx.lineWidth = 1.6;
      } else if (isBoundary) {
        ctx.strokeStyle = "rgba(96, 165, 250, 0.6)";
        ctx.lineWidth = 1.2;
      } else {
        ctx.strokeStyle = "rgba(217, 119, 6, 0.25)";
        ctx.lineWidth = 0.8;
      }
      ctx.stroke();

      // Add small sub-ticks (0.05 mm subdivisions) between lines
      if (idx < 10) {
        const ySubLine = yLine + 16;
        ctx.beginPath();
        ctx.moveTo(180, ySubLine);
        ctx.lineTo(220, ySubLine);
        ctx.strokeStyle = "rgba(217, 119, 6, 0.12)";
        ctx.lineWidth = 0.6;
        ctx.stroke();
      }

      // Numeric scale labels on the left (e.g. 0, 1, ..., 10)
      ctx.fillStyle = isBoundary ? "#60a5fa" : (isCenter ? "#f59e0b" : "rgba(245, 158, 11, 0.45)");
      ctx.font = "bold 9px monospace";
      ctx.textAlign = "right";
      ctx.fillText(idx.toString(), 44, yLine + 3);

      // Dimension labels on the right side (e.g., 0.5 mm)
      ctx.fillStyle = "rgba(245, 158, 11, 0.35)";
      ctx.font = "8px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`${(idx * 0.1).toFixed(1)} mm`, 356, yLine + 3.5);
    }

    // Vertical alignment crosshair (faint indicator)
    ctx.beginPath();
    ctx.moveTo(200, 30);
    ctx.lineTo(200, 370);
    ctx.strokeStyle = "rgba(180, 83, 9, 0.1)";
    ctx.lineWidth = 0.8;
    ctx.stroke();

    // Boundary text hints on the left margin
    if (scaleSDivs > 0) {
      ctx.fillStyle = "rgba(96, 165, 250, 0.4)";
      ctx.font = "normal 8px tahoma, sans-serif";
      ctx.textAlign = "left";
      ctx.fillText("شروع ردیابی", 56, startY - 5);
      ctx.fillText("پایان ردیابی", 56, endY + 12);
    }

    // 4. Draw droplets
    droplets.forEach((drop) => {
      // Depth focal blur determination
      const zDistance = Math.abs(drop.z - focusLevel);
      if (zDistance > 25) return; // not visible at this focal depth

      // Physical coordinate mapping with INVERTED optics:
      // Physical gravity fall makes drop.y decrease, visual viewportY decreases (moves UPwards).
      const viewportY = (drop.y - viewportMinY) / viewportHeight;
      const pixelY = 40 + viewportY * 320;
      const pixelX = 50 + drop.x * 300;

      // Ensure droplet is visually within the rounded viewport aperture
      const dx = pixelX - 200;
      const dy = pixelY - 200;
      if (Math.sqrt(dx * dx + dy * dy) > 176) return;

      const isSelected = drop.id === selectedId;
      const baseRadius = isSelected ? 3.0 : 2.2;

      // Add a highly realistic visual-only Brownian tremor that does not pollute actual physics state
      const tremorScale = (1.5e-6 / drop.radius) * 0.4; // micro-trembles (smaller drops oscillate faster)
      const renderX = pixelX + (Math.sin(Date.now() * 0.05 + drop.id) * tremorScale);
      const renderY = pixelY + (Math.cos(Date.now() * 0.04 + drop.id * 1.5) * tremorScale);

      // Focus properties:
      // zDistance of 0-1.5 is perfect focus. High zDistance expands blurred halo and fades opacity.
      const isFocused = zDistance <= 1.8;
      const blurRadius = isFocused ? 0 : (zDistance - 1.8) * 0.45;
      const opacity = isFocused ? 1.0 : Math.max(0.12, 1.0 - zDistance / 25);

      if (isFocused) {
        // Crisp high-contrast glowing micro-sphere
        ctx.beginPath();
        ctx.arc(renderX, renderY, baseRadius, 0, 2 * Math.PI);
        ctx.fillStyle = isSelected ? "#3b82f6" : "#fef08a";
        
        ctx.shadowColor = isSelected ? "#60a5fa" : "#fef08a";
        ctx.shadowBlur = isSelected ? 12 : 6;
        ctx.fill();
        ctx.shadowBlur = 0; // reset shadow immediately
      } else {
        // Out of focus: translucent blurry bokeh effect
        const visualRadius = baseRadius + blurRadius * 1.6;
        const dropletGrad = ctx.createRadialGradient(renderX, renderY, 0.5, renderX, renderY, visualRadius);
        
        const rColor = isSelected ? "59, 130, 246" : "253, 224, 71";
        dropletGrad.addColorStop(0, `rgba(${rColor}, ${opacity})`);
        dropletGrad.addColorStop(0.4, `rgba(${rColor}, ${opacity * 0.35})`);
        dropletGrad.addColorStop(1, "rgba(253, 224, 71, 0)");

        ctx.beginPath();
        ctx.arc(renderX, renderY, visualRadius, 0, 2 * Math.PI);
        ctx.fillStyle = dropletGrad;
        ctx.fill();
      }

      // Draw active targeting reticle around the selected one
      if (isSelected) {
        ctx.beginPath();
        ctx.arc(renderX, renderY, 13, 0, 2 * Math.PI);
        ctx.strokeStyle = "rgba(96, 165, 250, 0.8)";
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
        ctx.translate(renderX, renderY);
        ctx.rotate((Date.now() / 1200) % (2 * Math.PI)); // spin slowly
        ctx.stroke();
        ctx.setLineDash([]);
        // Reset transformation
        ctx.setTransform(1, 0, 0, 1, 0, 0);
      }
    });

    // Restore viewport clip restriction
    ctx.restore();

  }, [droplets, selectedId, focusLevel, scaleSDivs]);

  // Click handler to select droplets
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = 400 / rect.width;
    const scaleY = 400 / rect.height;
    
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    // Search for closest droplet within click tolerance
    let closestId: number | null = null;
    let minDistance = 24; // tolerance radius in px

    droplets.forEach((drop) => {
      const zDistance = Math.abs(drop.z - focusLevel);
      if (zDistance > 25) return; // must be reasonably scoped in depth

      const viewportY = (drop.y - viewportMinY) / viewportHeight;
      const pixelY = 40 + viewportY * 320;
      const pixelX = 50 + drop.x * 300;

      const dx = clickX - pixelX;
      const dy = clickY - pixelY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < minDistance) {
        minDistance = dist;
        closestId = drop.id;
      }
    });

    if (closestId !== null) {
      onSelectDroplet(closestId);
    }
  };

  const selectedDroplet = droplets.find((d) => d.id === selectedId);

  // Check if any droplets are focal-visible
  const visibleCount = droplets.filter((d) => Math.abs(d.z - focusLevel) <= 25).length;

  return (
    <div id="microscope-view-container" className="flex flex-col items-center">
      {/* Eyepiece Outer Bezel */}
      <div 
        id="eyepiece-bezel"
        className="relative w-80 h-80 sm:w-96 sm:h-96 rounded-full bg-linear-to-b from-gray-750 to-gray-905 p-3.5 shadow-2xl border-4 border-slate-650 flex items-center justify-center overflow-hidden"
      >
        {/* HTML5 Canvas Viewport replacing slow DOM element buttons */}
        <canvas
          id="microscope-canvas-viewport"
          ref={canvasRef}
          width={400}
          height={400}
          onClick={handleCanvasClick}
          className="relative w-full h-full rounded-full cursor-crosshair bg-slate-950 border-4 border-black select-none"
          style={{ boxShadow: "inset 0 0 35px rgba(0,0,0,0.95)" }}
        />

        {/* Empty room overlay */}
        {visibleCount === 0 && (
          <div id="no-droplets-warning" className="text-center p-4 max-w-xs text-xs text-slate-500 font-sans pointer-events-none absolute inset-0 flex flex-col justify-center items-center">
            <span className="text-amber-500/20 text-3xl font-bold mb-2">👁️</span>
            اتاقک خالی است یا خارج از فوکوس است.
            <br />
            ولتاژ را متوقف کرده و بالون لاستیکی را برای رهاسازی قطرات روغن فشار دهید. پیچ کانون‌ساز لنز را بچرخانید تا ذرات معلق پدیدار شوند.
          </div>
        )}
      </div>

      {/* Info labels below */}
      <div className="mt-3.5 flex flex-col items-center text-center">
        {selectedDroplet ? (
          <div className="text-xs bg-blue-500/10 border border-blue-500/20 text-blue-300 px-3.5 py-1 rounded-full flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            <span>
              ذره انتخابی: <strong className="font-mono">#{selectedDroplet.id}</strong> | 
              شاخص کانون (z): <strong className="font-mono">{selectedDroplet.z.toFixed(0)}</strong> | 
              بار الکترونیکی تخمینی: <strong className="font-mono text-amber-300">{selectedDroplet.chargeSign >= 0 ? `+${selectedDroplet.n}` : `-${selectedDroplet.n}`}e</strong>
            </span>
          </div>
        ) : (
          <div className="text-xs text-slate-400 bg-slate-800/40 border border-slate-700/30 px-3.5 py-1 rounded-full">
            💡 برای شروع آزمایش، <span className="text-amber-400 font-bold font-sans">یک قطره نورانی روشن را لمس کنید</span> تا هدف‌گیری فعال گردد.
          </div>
        )}
        <div className="mt-1 text-[10px] text-amber-500/75 font-mono">
          ⚠️ سیستم تصویر معکوس: سقوط واقعی به سمت پایین = صعود رو به بالا در چشمی میکروسکوپ
        </div>
      </div>
    </div>
  );
}
