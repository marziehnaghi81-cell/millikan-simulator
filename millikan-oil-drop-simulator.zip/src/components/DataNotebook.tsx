import React, { useState } from "react";
import { 
  FileSpreadsheet, 
  Trash2, 
  Info, 
  HelpCircle, 
  Calculator, 
  BookOpen, 
  LineChart, 
  FolderPlus,
  Compass,
  ArrowDownCircle,
  Sparkles
} from "lucide-react";
import { LabLog } from "../types";
import { 
  RHO_OIL, 
  RHO_AIR, 
  G_GRAVITY, 
  ETA_AIR, 
  PLATE_DISTANCE_D, 
  ELEMENTARY_CHARGE_E, 
  DIVISION_TO_METERS,
  calculateRadius,
  calculateChargeDynamic
} from "../physics";

interface DataNotebookProps {
  logs: LabLog[];
  onAddLog: (log: LabLog) => void;
  onDeleteLog: (id: string) => void;
  onClearLogs: () => void;
  onPreseedLogs: () => void;
  selectedDropletId: number | null;
  currentUf: number;
}

export default function DataNotebook({
  logs,
  onAddLog,
  onDeleteLog,
  onClearLogs,
  onPreseedLogs,
  selectedDropletId,
  currentUf,
}: DataNotebookProps) {
  const [activeTab, setActiveTab] = useState<"table" | "theory" | "protocol">("table");
  
  // Local state for adding a manual log row if they want to fine-tune
  const [manualId, setManualId] = useState<string>("");
  const [manualUf, setManualUf] = useState<number>(220);
  const [manualU2, setManualU2] = useState<number>(360);
  const [manualS, setManualS] = useState<number>(5);
  const [manualT1, setManualT1] = useState<number>(5.2);
  const [manualT2, setManualT2] = useState<number>(4.1);

  // Protocol checkboxes
  const [checkedSteps, setCheckedSteps] = useState<boolean[]>(new Array(10).fill(false));

  const toggleStep = (index: number) => {
    const updated = [...checkedSteps];
    updated[index] = !updated[index];
    setCheckedSteps(updated);
  };

  const handleAddManualRow = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Perform physical calculations manually for row addition
    const v1 = (manualS * DIVISION_TO_METERS) / manualT1;
    const v2 = (manualS * DIVISION_TO_METERS) / manualT2;
    const r = calculateRadius(v1);
    const q = calculateChargeDynamic(manualU2, r, v1, v2);
    
    const n = Math.max(1, Math.round(q / ELEMENTARY_CHARGE_E));
    const eExp = q / n;
    const errorPercent = Math.abs((eExp - ELEMENTARY_CHARGE_E) / ELEMENTARY_CHARGE_E) * 100;

    const newLog: LabLog = {
      id: "manual_" + Date.now(),
      dropletId: Number(manualId) || Math.floor(Math.random() * 800) + 100,
      n,
      r,
      uF: manualUf,
      u2: manualU2,
      sDivs: manualS,
      t1: manualT1,
      t2: manualT2,
      v1,
      v2,
      qCalculated: q,
      errorPercent,
    };

    onAddLog(newLog);
    // Reset manual ID
    setManualId("");
  };

  return (
    <div 
      id="laboratory-notebook"
      className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg w-full flex flex-col gap-4"
    >
      {/* Notebook Tabs */}
      <div className="flex border-b border-slate-800 gap-1 overflow-x-auto">
        <button
          onClick={() => setActiveTab("table")}
          className={`px-4 py-2 border-b-2 text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
            activeTab === "table"
              ? "border-amber-500 text-amber-500"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          جدول ثبت گزارش آزمایش
        </button>
        <button
          onClick={() => setActiveTab("protocol")}
          className={`px-4 py-2 border-b-2 text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
            activeTab === "protocol"
              ? "border-amber-500 text-amber-500"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <Compass className="w-3.5 h-3.5" />
          دستورکار گام‌به‌گام ({checkedSteps.filter(Boolean).length}/۱۰)
        </button>
        <button
          onClick={() => setActiveTab("theory")}
          className={`px-4 py-2 border-b-2 text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
            activeTab === "theory"
              ? "border-amber-500 text-amber-500"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          فرمول‌ها و مبانی فیزیکی
        </button>
      </div>

      {/* TABS CONTENT */}
      {activeTab === "table" && (
        <div className="flex flex-col gap-6 animate-fade-in">
          {/* Primary Action bar */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs text-slate-400 font-sans">
              تعداد ردیف‌های ثبت شده: <strong className="font-mono text-amber-400">{logs.length}</strong>
            </span>
            <div className="flex gap-2.5">
              {logs.length === 0 && (
                <button
                  onClick={onPreseedLogs}
                  className="flex items-center gap-1 bg-yellow-500/10 hover:bg-yellow-500/20 border border-yellow-500/30 text-yellow-300 py-1.5 px-3 rounded-lg text-[11px] font-bold cursor-pointer transition-colors"
                >
                  <Sparkles className="w-3 h-3" />
                  بارگذاری داده‌های پیش‌فرض نمونه
                </button>
              )}
              {logs.length > 0 && (
                <button
                  onClick={onClearLogs}
                  className="flex items-center gap-1 bg-red-950 hover:bg-red-900 border border-red-800 text-red-200 py-1.5 px-3 rounded-lg text-[11px] font-bold cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                  پاکسازی کل جدول
                </button>
              )}
            </div>
          </div>

          {/* Table display */}
          <div className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-950/40">
            <table className="w-full text-right text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-300 border-b border-slate-800">
                  <th className="p-3 text-center w-14">ذره #</th>
                  <th className="p-3 text-center">ولتاژ تعلیق U_f<br />(v)</th>
                  <th className="p-3 text-center">ولتاژ صعود U_2<br />(v)</th>
                  <th className="p-3 text-center">بازه حرکتی S<br />(div)</th>
                  <th className="p-3 text-center">زمان سقوط t_1<br />(s)</th>
                  <th className="p-3 text-center">زمان صعود t_2<br />(s)</th>
                  <th className="p-3 text-center">شعاع طولی r<br />(10⁻⁶ m)</th>
                  <th className="p-3 text-center font-bold text-amber-400">بار محاسبه شده q<br />(10⁻¹⁹ C)</th>
                  <th className="p-3 text-center">تعداد بارها n</th>
                  <th className="p-3 text-center text-emerald-400">بار بنیادی e_exp<br />(10⁻¹⁹ C)</th>
                  <th className="p-3 text-center">سطح خطا<br />(%)</th>
                  <th className="p-3 text-center w-10">لغو</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono text-[11.5px] text-slate-300">
                {logs.length === 0 ? (
                  <tr>
                    <td colSpan={12} className="p-8 text-center text-slate-500 font-sans">
                      جدول خالی است. با انتخاب ذره و اندازه‌گیری زمان‌ها مکرراً دکمه‌های "ثبت زمان" کرونومتر را فشار دهید و یا داده‌های آماده بارگذاری کنید.
                    </td>
                  </tr>
                ) : (
                  logs.map((log) => {
                    const qScaled = (log.qCalculated * 1e19).toFixed(3);
                    const eExpScaled = ((log.qCalculated / log.n) * 1e19).toFixed(3);
                    const rScaled = (log.r * 1e6).toFixed(3);
                    return (
                      <tr key={log.id} className="hover:bg-slate-900/50 transition-colors">
                        <td className="p-2.5 text-center text-blue-400 font-bold">#{log.dropletId}</td>
                        <td className="p-2.5 text-center">{log.uF.toFixed(0)} V</td>
                        <td className="p-2.5 text-center">{log.u2.toFixed(0)} V</td>
                        <td className="p-2.5 text-center">{log.sDivs}</td>
                        <td className="p-2.5 text-center text-amber-300">{log.t1.toFixed(2)}s</td>
                        <td className="p-2.5 text-center text-emerald-300">{log.t2.toFixed(2)}s</td>
                        <td className="p-2.5 text-center">{rScaled} µm</td>
                        <td className="p-2.5 text-center font-bold text-amber-400">{qScaled}</td>
                        <td className="p-2.5 text-center text-white bg-slate-900/80 rounded px-1.5 py-0.5 inline-block my-1.5 font-bold">{log.n} e</td>
                        <td className="p-2.5 text-center text-emerald-400 font-bold">{eExpScaled}</td>
                        <td className={`p-2.5 text-center font-bold ${log.errorPercent < 5 ? 'text-emerald-400' : 'text-amber-500'}`}>
                          {log.errorPercent.toFixed(1)}%
                        </td>
                        <td className="p-2.5 text-center">
                          <button
                            id={`delete-log-${log.id}`}
                            onClick={() => onDeleteLog(log.id)}
                            className="text-slate-500 hover:text-red-400 p-1 cursor-pointer"
                            title="حذف ردیف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Quick Info Warning about Quantization */}
          {logs.length > 0 && (
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1.5">
                <LineChart className="w-4 h-4 text-emerald-400" />
                تحلیل آماری بار الکترونی حاصل از آزمایش
              </h4>
              <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                به ستون <strong className="text-amber-400">بار محاسبه شکل (q)</strong> دقت کنید. مقادیر محاسبه شده به صورت کوانتیده (پله‌ای) در اطراف مضارب صحیح عدد طلایی <span className="text-emerald-400 font-mono font-bold">۱.۶e-۱۹ کولن</span> قرار دارند (حدود ۳.۲، ۴.۸، ۶.۴، ۸.۰ و ...).
                مقدار میانگین بار به دست آمده برای ستون بار بنیادی در آزمایش شما برابر است با:{" "}
                <strong className="text-emerald-400 font-mono text-[12px]">
                  {(logs.reduce((acc, log) => acc + (log.qCalculated / log.n), 0) / logs.length * 1e19 || 0).toFixed(3)} × 10⁻¹⁹ C
                </strong>
              </p>
            </div>
          )}

          {/* Manual Input Tool */}
          <form onSubmit={handleAddManualRow} className="bg-slate-950/60 p-4 rounded-lg border border-slate-800 flex flex-col gap-3">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Calculator className="w-3.5 h-3.5 text-amber-500" />
              افزودن دستی یا اصلاح ثبت محاسبات
            </h4>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">کد ذره</label>
                <input
                  type="number"
                  placeholder="مثلا 105"
                  value={manualId}
                  onChange={(e) => setManualId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">تعلیق U_f (V)</label>
                <input
                  type="number"
                  value={manualUf}
                  onChange={(e) => setManualUf(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">ولتاژ صعود U_2 (V)</label>
                <input
                  type="number"
                  value={manualU2}
                  onChange={(e) => setManualU2(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">بخش‌های شبکه S</label>
                <input
                  type="number"
                  value={manualS}
                  onChange={(e) => setManualS(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">زمان سقوط t_1 (s)</label>
                <input
                  type="number"
                  step="0.01"
                  value={manualT1}
                  onChange={(e) => setManualT1(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">زمان صعود t_2 (s)</label>
                <input
                  type="number"
                  step="0.01"
                  value={manualT2}
                  onChange={(e) => setManualT2(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-1 text-xs text-white"
                />
              </div>
            </div>

            <button
              id="add-manual-record-btn"
              type="submit"
              className="mt-2 text-xs bg-slate-800 hover:bg-slate-700 text-amber-400 p-1.5 rounded font-bold cursor-pointer transition-colors text-center"
            >
              ثبت و محاسبه دستی ردیف در جدول
            </button>
          </form>
        </div>
      )}

      {activeTab === "protocol" && (
        <div className="flex flex-col gap-4 animate-fade-in text-xs text-slate-300 leading-relaxed font-sans">
          <div className="bg-slate-950/40 p-4 rounded-lg border border-slate-800">
            <h4 className="font-bold text-amber-400 flex items-center gap-1.5 mb-3 text-sm">
              <Compass className="w-4 h-4" />
              راهنمای تعاملی گام به گام انجام آزمایش میلیکان
            </h4>
            <div className="flex flex-col gap-3">
              {[
                "تنظیم ولتاژ روی ۲۰۰ ولت (از نوار لغزان ولتاژ زیر میکروسکوپ کاراکتر را روی ۲۰۰ تنظیم کنید).",
                "پاشش اولیه قطرات روغن: دکمه بالون قرمز رنگ را یکبار سریع فشار دهید تا غبار قطرات روغن وارد میدان دید تعلیق شود.",
                "کانون‌سازی تصویر: نوار لغزان 'پیچ کانون‌ساز' را به چپ و راست حرکت دهید تا قطرات معلق به صورت نقاط تابان و متمرکز درآیند.",
                "انتظام حرکت قطرات: متوجه شوید پس از کانون‌سازی هر ذره، ذرات بی‌بار سقوط کرده، ذرات منفی رو به پایین (میکروسکوپ معکوس: یعنی رو به بالا) و ذرات باردار مثبت در حرکتند.",
                "انتخاب و صفر کردن سرعت (تعلیق): یک قطره باردار که تعادل پسیو دارد انتخاب کنید (کلیک کنید). ولتاژ را طوری دقیق تغییر دهید (بین ۱۰۰ تا ۳۰۰) تا ذره در مرکز میدان دید کاملا بی حرکت شود (مکان ثابت به مدت ۳۰ ثانیه). این ولتاژ را به نام ولتاژ تعلیق U_f در نظر بگیرید.",
                "اندازه‌گیری دقت تعلیق: متوجه شوید با تغییرات بسیار جزئی ولتاژ ذره ساکن می‌ماند. این دامنه تحمل ولتاژ نشان‌دهنده خطای آزمایش مابین ذرات همنام است.",
                "مرحله شروع سقوط آزاد (اندازه‌گیری t₁): دکمه روشن/خاموش ولتاژ را روی OFF (صفر ولت) بگذارید. قطره سریعاً حرکت رو به بالای خود در عینک میکروسکوپ (سقوط واقعی) را شروع می‌کند.",
                "روشن کردن کرونومتر: به محض عبور لبه قطره از یک نشانگر بزرگ فرضی (مثلاً خط ۳) کرونومتر را استارت کنید و پس از طی تعداد S تقسیم‌بندی بزرگ (مثلا ۵ خط تا خط ۸) آن را متوقف کرده و ثبت t₁ کنید.",
                "مرحله صعود اجباری با پتانسیل ثانویه (اندازه‌گیری t₂): کلید ولتاژ را مجدداً روشن کنید و آن را روی ولتاژ اعمالی U_2 (مثلاً ۳۰۰ الی ۴۰۰ ولت) تنظیم کنید تا ذره رو به پایین حرکت کند. با کرونومتر زمان طی همان گام S خط را اندازه بگیرید و بعنوان t₂ ثبت کنید.",
                "تحلیل و گزارش کار: اکنون با کلیک بر روی ردیف‌ها و بررسی q محاسبه شده، مشاهده کنید چگونه مضارب کامل q بر بار بنیادی ۱.۶e-۱۹ کولن توصیف‌کننده پدیده کوانتش بار الکتریکی است."
              ].map((step, index) => (
                <label 
                  key={index} 
                  className="flex items-start gap-2.5 p-2 rounded-md hover:bg-slate-800/20 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={checkedSteps[index]}
                    onChange={() => toggleStep(index)}
                    className="mt-0.5 rounded border-slate-700 text-amber-500 focus:ring-amber-500 w-4 h-4 shrink-0 cursor-pointer"
                  />
                  <div className={checkedSteps[index] ? "line-through text-slate-500" : ""}>
                    <strong className="text-amber-500 font-mono ml-1">{index + 1}.</strong>
                    {step}
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "theory" && (
        <div className="flex flex-col gap-4 animate-fade-in text-xs text-slate-300 leading-relaxed font-sans">
          <div className="bg-slate-950/40 p-4 rounded-lg border border-slate-800 flex flex-col gap-4">
            <h4 className="font-bold text-amber-400 flex items-center gap-1.5 text-sm border-b border-slate-800 pb-2">
              <BookOpen className="w-4 h-4" />
              تئوری فیزیکی و مبانی کوانتش بار میلیکان
            </h4>

            <div>
              <h5 className="font-bold text-slate-200 mb-1">۱. محاسبه شعاع قطره (نیروی پسا استوکس)</h5>
              <p className="text-slate-400 mb-2">
                وقتی میدان الکتریکی خاموش است (E=0)، قطره به دلیل نیروی ثقل به صورت سقوط آزاد حرکت می‌کند. پس از طی مسافت کوتاه، نیروی مقاومت هوا (پسا استوکس) با جاذبه هم‌جهت می‌گردد و سرعت به حد نهایی v₁ می‌رسد:
              </p>
              <div className="bg-black/40 p-2.5 rounded font-mono text-center text-amber-300 text-[12px] my-1.5">
                r = √ [ 9 * η * v₁ / (2 * (ρ_oil - ρ_air) * g) ]
              </div>
              <ul className="list-disc pl-4 text-[10.5px] text-slate-400 flex flex-col gap-0.5 font-sans">
                <li>η (گرانرانی هوا) = ۱.۸۱ × ۱۰<sup>-۵</sup> Pa·s</li>
                <li>ρ<sub>oil</sub> (چگالی روغن) = ۸۷۵ kg/m<sup>3</sup> | ρ<sub>air</sub> (چگالی هوا) = ۱.۲۹ kg/m<sup>3</sup></li>
                <li>g (شتاب گرانش) = ۹.۸ m/s<sup>2</sup></li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-slate-200 mb-1 font-sans">۲. محاسبه مقدار بار الکتریکی (روش حرکتی یا دینامیک)</h5>
              <p className="text-slate-400 mb-2">
                وقتی ولتاژ ثانویه U₂ اعمال می‌شود، میدان به شدت قطره را تحت فشار قرار می‌دهد تا صعود کند. سرعت صعود حد v₂ اندازه‌گیری می‌شود. از برآیند نیروهای وارد بر قطره معلق روغن:
              </p>
              <div className="bg-black/40 p-2.5 rounded font-mono text-center text-amber-300 text-[12px] my-1.5">
                q = [ 6 * π * η * r * d * (v₁ + v₂) ] / U₂
              </div>
              <p className="text-slate-400">
                که در آن d فاصله بین دو صفحه خازن معادل ۱.۶ میلی‌متر می‌باشد.
              </p>
            </div>

            <div>
              <h5 className="font-bold text-slate-200 mb-1">۳. خطای آزمایشگاهی و پدیده کوانتش</h5>
              <p className="text-slate-400">
                در واقعیت، آزمایشگاه فیزیک عاری از پاسخ‌های صلب ریاضیاتی مطلق است. عوامل انسانی مانند خطای عکس‌العمل در فشردن کرونومتر (حدود ۰.۱۵ ثانیه)، حرکت براونی زیگزاگ قطرات ناشی از برخوردهای حرارتی مولکول‌های هوا، و چگالی نوری هوا باعث پراکندگی نقاط اندازه‌گیری می‌شوند. علی‌رغم این خطاهای تجربی، همواره نسبت بار کل به بار بنیادی q/e به اعداد صحیح همگرا می‌شود که گواه کوانتیده بودن بار الکتریکی الکترون است.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
