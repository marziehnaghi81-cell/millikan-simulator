import React, { useState, useEffect, useRef } from "react";
import { Timer, Play, Pause, RotateCcw, ArrowRight, CheckCircle2 } from "lucide-react";

interface StopwatchProps {
  onTransferTime: (timeSeconds: number, target: "t1" | "t2") => void;
  selectedDropletId: number | null;
}

export default function Stopwatch({ onTransferTime, selectedDropletId }: StopwatchProps) {
  const [time, setTime] = useState<number>(0); // in milliseconds
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedTimeRef = useRef<number>(0);

  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = Date.now() - pausedTimeRef.current;
      timerRef.current = setInterval(() => {
        setTime(Date.now() - startTimeRef.current);
      }, 10); // Update every 10ms for centisecond precision
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      pausedTimeRef.current = time;
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning]);

  const handleStartStop = () => {
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTime(0);
    pausedTimeRef.current = 0;
  };

  // Format milliseconds to mm:ss.SS
  const formatTime = (ms: number) => {
    const totalSeconds = ms / 1000;
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const centiseconds = Math.floor((ms % 1000) / 10);

    const pad = (num: number, size: number = 2) => {
      let s = num + "";
      while (s.length < size) s = "0" + s;
      return s;
    };

    return {
      minutes: pad(minutes),
      seconds: pad(seconds),
      centiseconds: pad(centiseconds),
      formatted: `${pad(minutes)}:${pad(seconds)}.${pad(centiseconds)}`
    };
  };

  const { minutes, seconds, centiseconds } = formatTime(time);
  const secondsValue = Number((time / 1000).toFixed(3));

  return (
    <div 
      id="laboratory-stopwatch"
      className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col gap-4 w-full"
    >
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <Timer className="w-4 h-4 text-emerald-400" />
          کرونومتر دیجیتال میکروثانیه
        </h3>
        <span className="text-[10px] bg-emerald-950/60 border border-emerald-900/40 text-emerald-400 px-2.5 py-0.5 rounded-full font-sans">
          دقت: ۰.۰۱ ثانیه
        </span>
      </div>

      {/* Numerical Display */}
      <div className="bg-black border-2 border-slate-800 rounded-lg py-5 px-6 flex items-center justify-center font-mono text-center shadow-inner relative overflow-hidden">
        {/* Subtle grid pattern background to look like a real LCD screen */}
        <div className="absolute inset-0 bg-radial from-slate-900/10 to-transparent pointer-events-none" />
        
        {/* Digital numbers */}
        <div className="flex items-baseline text-4xl font-mono text-emerald-400 tracking-wider">
          <span>{minutes}</span>
          <span className="animate-pulse mx-1 text-emerald-500/60">:</span>
          <span>{seconds}</span>
          <span className="text-emerald-500/70 mx-0.5">.</span>
          <span className="text-2xl text-emerald-400/80">{centiseconds}</span>
          <span className="text-xs text-emerald-500/50 ml-1 font-sans">ثانیه</span>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button
          id="stopwatch-start-stop-btn"
          onClick={handleStartStop}
          className={`flex items-center justify-center gap-1.5 py-2 px-4 rounded-lg font-bold text-xs select-none cursor-pointer transition-colors ${
            isRunning 
              ? "bg-amber-500 hover:bg-amber-600 text-slate-950" 
              : "bg-emerald-500 hover:bg-emerald-600 text-slate-950"
          }`}
        >
          {isRunning ? (
            <>
              <Pause className="w-4 h-4 fill-slate-950" />
              توقف زمان‌گیری
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-slate-950" />
              شروع زمان‌گیری
            </>
          )}
        </button>

        <button
          id="stopwatch-reset-btn"
          onClick={handleReset}
          className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 py-2 px-4 rounded-lg font-bold text-xs cursor-pointer select-none transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          صفر کردن (Reset)
        </button>
      </div>

      {/* Direct Record Integrations */}
      <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col gap-2 mt-1">
        <span className="text-[10px] text-slate-400 font-bold block mb-1">
          📥 ثبت مستقیم زمان اندازه‌گیری شده ({secondsValue.toFixed(2)}s) در ردیف فعال:
        </span>
        
        <div className="grid grid-cols-2 gap-2">
          <button
            id="transfer-t1-btn"
            disabled={time === 0}
            onClick={() => onTransferTime(secondsValue, "t1")}
            className="flex items-center justify-center gap-1 bg-blue-900/30 hover:bg-blue-900/50 border border-blue-800/40 disabled:opacity-40 disabled:pointer-events-none text-blue-300 py-1.5 px-2.5 rounded-md text-[11px] font-sans transition-colors cursor-pointer"
          >
            <ArrowRight className="w-3 h-3 text-blue-400 shrink-0" />
            ثبت زمان سقوط t₁
          </button>

          <button
             id="transfer-t2-btn"
            disabled={time === 0}
            onClick={() => onTransferTime(secondsValue, "t2")}
            className="flex items-center justify-center gap-1 bg-emerald-900/30 hover:bg-emerald-900/50 border border-emerald-800/40 disabled:opacity-40 disabled:pointer-events-none text-emerald-300 py-1.5 px-2.5 rounded-md text-[11px] font-sans transition-colors cursor-pointer"
          >
            <ArrowRight className="w-3 h-3 text-emerald-400 shrink-0" />
            ثبت زمان صعود t₂
          </button>
        </div>

        {selectedDropletId === null ? (
          <p className="text-[9px] text-red-400/80 text-center mt-1">
            ⚠️ هنوز هیچ ذره‌ای انتخاب نشده است. لطفاً ابتدا ذره‌ای را در میکروسکوپ کلیک کنید.
          </p>
        ) : (
          <p className="text-[9px] text-emerald-400/80 text-center mt-1 flex items-center justify-center gap-1 font-sans">
            <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
            تجهیز متصل به ذره معلق <span className="font-mono">#{selectedDropletId}</span>
          </p>
        )}
      </div>
    </div>
  );
}
