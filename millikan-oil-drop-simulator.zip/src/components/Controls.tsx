import React from "react";
import { Zap, Play, RotateCcw, ShieldAlert, Sparkles, Sliders } from "lucide-react";

interface ControlsProps {
  voltage: number;
  setVoltage: (v: number) => void;
  voltageEnabled: boolean;
  setVoltageEnabled: (b: boolean) => void;
  polarity: "normal" | "reverse";
  setPolarity: (p: "normal" | "reverse") => void;
  focusLevel: number;
  setFocusLevel: (f: number) => void;
  onSqueezeBulb: () => void;
  squeezeCount: number;
  onClearChamber: () => void;
}

export default function Controls({
  voltage,
  setVoltage,
  voltageEnabled,
  setVoltageEnabled,
  polarity,
  setPolarity,
  focusLevel,
  setFocusLevel,
  onSqueezeBulb,
  squeezeCount,
  onClearChamber,
}: ControlsProps) {
  return (
    <div 
      id="laboratory-console"
      className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg w-full flex flex-col gap-6"
    >
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-amber-500" />
          کنسول فرمان و کنترل سنجه‌ها
        </h3>
        <div className="text-[10px] bg-slate-800 text-slate-400 px-2.5 py-0.5 rounded-full font-mono">
          MODEL: MK-IV
        </div>
      </div>

      {/* Squeeze Balloon & Clear chamber */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Rubber Bulb Spray Area */}
        <div className="flex flex-col items-center justify-center bg-slate-950/55 rounded-lg p-4 border border-slate-800/60 relative">
          <label className="text-xs text-slate-400 font-medium mb-3">۱. پاشش قطرات با بالون لاستیکی</label>
          
          <button
            id="balloon-pump-btn"
            onClick={onSqueezeBulb}
            className="group relative flex flex-col items-center justify-center p-2 rounded-full transition-all duration-150 active:scale-95 text-amber-500 hover:text-amber-400"
          >
            {/* Balloon SVG */}
            <div className="w-20 h-20 relative bg-linear-to-b from-red-500 to-red-700 hover:from-red-400 hover:to-red-600 active:from-red-600 active:to-red-800 rounded-full flex flex-col items-center justify-center shadow-md cursor-pointer transition-transform duration-100 group-hover:scale-105 group-active:scale-90"
                 style={{ borderBottomLeftRadius: "50% 65%", borderBottomRightRadius: "50% 65%" }}>
              {/* Balloon stem */}
              <div className="absolute -bottom-2 w-4 h-4 bg-red-800 border-t border-red-900 rounded-b-xs" />
              <div className="absolute -bottom-3 w-5 h-1.5 bg-gray-700 rounded-sm" />
              <span className="text-white text-[10px] font-bold select-none font-sans mt-2">پمپ پاشش</span>
            </div>
          </button>

          <span className="text-[10px] text-slate-500 mt-4 text-center">
            تعداد فشار سریع بالون: <strong className="text-amber-400 font-mono">{squeezeCount} بار</strong>
          </span>

          {squeezeCount > 1 && (
            <div className="absolute inset-x-2 -bottom-2 translate-y-full z-20 flex gap-2 items-start bg-red-950/90 border border-red-800/50 p-2.5 rounded-md text-red-200 text-[10.5px]">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-red-300 block mb-0.5">خطای تراکم بالای باردار!</strong>
                پمپ مجدد بالون منجر به اشباع اتاقک و نیروی دوقطبی همسایه خواهد شد. برای دقت آزمایش ولتاژ را قطع و محفظه را تخلیه کنید.
              </div>
            </div>
          )}
        </div>

        {/* Focus Knob / Clear Chamber Area */}
        <div className="flex flex-col justify-between bg-slate-950/55 rounded-lg p-4 border border-slate-800/60">
          <div className="flex flex-col">
            <label className="text-xs text-slate-400 font-medium mb-1.5 flex justify-between">
              <span>۲. پیچ کانون‌ساز لنز</span>
              <span className="font-mono text-amber-400 font-semibold">{focusLevel.toFixed(0)}%</span>
            </label>
            <input
              id="focus-level-slider"
              type="range"
              min="0"
              max="100"
              step="1"
              value={focusLevel}
              onChange={(e) => setFocusLevel(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <p className="text-[9.5px] text-slate-500 mt-1">
              با تغییر فاصله کانونی میکروسکوپ، قطرات معلق در اعماق مختلف کانونی به صورت کاملاً تفکیک‌شده و درخشان دیده می‌شوند.
            </p>
          </div>

          <button
            id="clear-chamber-btn"
            onClick={onClearChamber}
            className="mt-4 w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 py-1.5 px-3 rounded-md text-xs font-medium cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
            قطع میدان و تخلیه رسوبی قطرات
          </button>
        </div>
      </div>

      {/* Voltage Regulator & Electrode Switch */}
      <div className="bg-slate-950/80 rounded-lg p-4 border border-slate-800 flex flex-col gap-4 mt-2">
        <label className="text-xs text-slate-300 font-bold flex items-center gap-1">
          <Zap className="w-3.5 h-3.5 text-yellow-500" />
          تنظیم اختلاف پتانسیل خازن (U)
        </label>

        <div className="flex flex-col sm:flex-row items-center gap-4 justify-between">
          {/* Main Power Switch */}
          <div className="flex items-center gap-3">
            <button
              id="power-[#voltage-switch]"
              onClick={() => setVoltageEnabled(!voltageEnabled)}
              className={`relative cursor-pointer w-24 h-10 rounded-lg flex items-center justify-center text-xs font-bold transition-all border ${
                voltageEnabled
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500 hover:bg-emerald-500/30"
                  : "bg-red-500/10 text-red-400 border-red-500/40 hover:bg-red-500/20"
              }`}
            >
              {voltageEnabled ? (
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                  ولتاژ وصل (ON)
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                  ولتاژ قطع (OFF)
                </span>
              )}
            </button>

            {/* Polarity Switch */}
            <button
              id="polarity-switch"
              onClick={() => setPolarity(polarity === "normal" ? "reverse" : "normal")}
              className="px-3 h-10 border border-slate-700 hover:bg-slate-800 text-slate-300 rounded-lg text-xs font-medium cursor-pointer transition-colors flex flex-col justify-center items-center gap-0.5"
            >
              <span className="text-[9px] text-slate-500 block">قطبیت صفحات</span>
              <strong className="font-mono text-[10.5px]">
                {polarity === "normal" ? "+ بالا / - پایین" : "- بالا / + پایین"}
              </strong>
            </button>
          </div>

          {/* Large Digital Meter Display */}
          <div className="bg-black/90 rounded-md border border-slate-800 px-4 py-2 flex flex-col items-center min-w-[120px] shadow-inner">
            <span className="text-[10px] text-yellow-500/70 font-bold mb-0.5 tracking-wider">VOLT METER</span>
            <span className="font-mono text-xl text-yellow-400 font-black tracking-widest">
              {voltageEnabled ? `${voltage.toFixed(0)}` : "000"}<span className="text-yellow-400/40 text-xs font-normal"> V</span>
            </span>
          </div>
        </div>

        {/* Voltage continuous slider */}
        <div className="mt-2 flex flex-col gap-1">
          <div className="flex justify-between text-xs text-slate-500 font-mono">
            <span>0 V</span>
            <span className="text-slate-400">ولتاژ انتخابی: {voltage.toFixed(0)} ولت</span>
            <span>600 V</span>
          </div>
          <input
            id="voltage-slider"
            type="range"
            min="0"
            max="600"
            step="1"
            value={voltage}
            onChange={(e) => {
              setVoltage(Number(e.target.value));
              // Automatically turn on if slider is manipulated
              if (!voltageEnabled) setVoltageEnabled(true);
            }}
            className="w-full h-2.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-yellow-500"
          />
        </div>

        {/* Protocol helper benchmarks */}
        <div className="flex justify-between items-center bg-slate-900/60 p-2 rounded border border-slate-800/40 text-[10px] text-slate-400">
          <span>محدوده پذیرش تعلیق دستور کار:</span>
          <div className="flex gap-2">
            <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 font-mono">100V - 300V</span>
            <span className="text-slate-500">خارج از این رنج خطای آماری دارد</span>
          </div>
        </div>
      </div>
    </div>
  );
}
