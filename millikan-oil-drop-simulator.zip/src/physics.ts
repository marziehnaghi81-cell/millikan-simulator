// Physical Constants for Millikan's Oil Drop Experiment
export const RHO_OIL = 875.0; // density of oil in kg/m^3
export const RHO_AIR = 1.29;  // density of air in kg/m^3
export const G_GRAVITY = 9.8;  // acceleration due to gravity in m/s^2
export const ETA_AIR = 1.81e-5; // dynamic viscosity of air in Pa*s (N*s/m^2)
export const PLATE_DISTANCE_D = 0.0016; // plate separation d = 1.6 mm (in meters)
export const ELEMENTARY_CHARGE_E = 1.602176634e-19; // actual electron charge in Coulombs

// Cunningham correction factor parameters (Stoke's law correction for small droplets)
export const CONST_B = 8.22e-3; // correction constant in Pa*m
export const CONST_P = 101325;  // air pressure in Pa (standard 1 atm)

// Conversion factor for microscope divisions
// 1 major division (grid mark) = 0.1 mm = 1.0e-4 meters
export const DIVISION_TO_METERS = 1.0e-4; 

/**
 * Calculates the radius r of the oil droplet in meters using Stokes' law.
 * Formula: r = sqrt( 9 * eta * v1 / (2 * (rho_oil - rho_air) * g) )
 */
export function calculateRadius(v1: number): number {
  if (v1 <= 0) return 0;
  const numerator = 9 * ETA_AIR * v1;
  const denominator = 2 * (RHO_OIL - RHO_AIR) * G_GRAVITY;
  return Math.sqrt(numerator / denominator);
}

/**
 * Calculates the effective mass of the droplet (accounting for buoyancy)
 * m_eff = (4/3) * pi * r^3 * (rho_oil - rho_air)
 */
export function calculateEffectiveWeight(r: number): number {
  return (4 / 3) * Math.PI * Math.pow(r, 3) * (RHO_OIL - RHO_AIR) * G_GRAVITY;
}

/**
 * Static balancing method: Calculates charge q based on suspension voltage Uf
 * q = (m_eff * g * d) / Uf
 */
export function calculateChargeStatic(uF: number, r: number): number {
  if (uF <= 0 || r <= 0) return 0;
  const weightEff = calculateEffectiveWeight(r);
  return (weightEff * PLATE_DISTANCE_D) / uF;
}

/**
 * Dynamic method: Calculates charge q based on rising voltage U2, falling speed v1, and rising speed v2
 * q = (6 * pi * eta * r * d * (v1 + v2)) / U2
 */
export function calculateChargeDynamic(u2: number, r: number, v1: number, v2: number): number {
  if (u2 <= 0 || r <= 0) return 0;
  const numerator = 6 * Math.PI * ETA_AIR * r * PLATE_DISTANCE_D * (v1 + v2);
  return numerator / u2;
}

/**
 * Applies the Cunningham correction factor to the calculated charge.
 * Qc = Q * ( (r * P) / (b + r * P) )^1.5
 */
export function getCorrectedCharge(q: number, r: number): number {
  if (q <= 0 || r <= 0) return q;
  const ratio = (r * CONST_P) / (CONST_B + r * CONST_P);
  return q * Math.pow(ratio, 1.5);
}

/**
 * Estimates the nearest integer number of elementary charges (electrons)
 */
export function estimateChargeCount(q: number): number {
  if (q <= 0) return 0;
  return Math.max(1, Math.round(q / ELEMENTARY_CHARGE_E));
}

