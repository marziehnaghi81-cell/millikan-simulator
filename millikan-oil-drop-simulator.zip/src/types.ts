export interface Droplet {
  id: number;
  x: number; // horizontal position in the microscope view (0.0 to 1.0 mm)
  y: number; // vertical position in the physical chamber (0.0 to 1.5 mm). 0 = bottom plate, 1.5 = top plate
  z: number; // depth dimension (0 to 100 mm virtual depth), used for focusing
  radius: number; // radius in meters (typically 0.8e-6 to 2.5e-6 m)
  charge: number; // charge in Coulombs (integer multiple of e, e.g. n * 1.602e-19 C)
  n: number; // number of elementary charges (integer)
  chargeSign: number; // -1, 1, or 0 (neutral)
  
  // Brownian motion or air drift perturbation
  driftX: number; 
  driftY: number;
}

export interface LabLog {
  id: string;
  dropletId: number;
  n: number;           // calculated/estimated number of electrons
  r: number;           // calculated radius (m)
  uF: number;          // suspension voltage (V)
  u2: number;          // dynamic voltage (V)
  sDivs: number;       // number of subdivisions traveled
  t1: number;          // falling time with V=0 (s)
  t2: number;          // rising time with V=U2 (s)
  v1: number;          // falling velocity (m/s)
  v2: number;          // rising velocity (m/s)
  qCalculated: number; // calculated charge (C)
  errorPercent: number; // error from closest multiple of e or actual e
}
