import React, { useState, useEffect, useRef } from "react";
import { 
  Atom, 
  HelpCircle, 
  Cpu, 
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Award,
  BookOpen,
  Database,
  ArrowRight,
  PlusCircle,
  HelpCircle as HelpIcon,
  Layers,
  ChevronLeft
} from "lucide-react";
import MicroscopeView from "./components/MicroscopeView";
import Controls from "./components/Controls";
import Stopwatch from "./components/Stopwatch";
import DataNotebook from "./components/DataNotebook";
import { Droplet, LabLog } from "./types";
import { 
  RHO_OIL, 
  RHO_AIR, 
  G_GRAVITY, 
  ETA_AIR, 
  PLATE_DISTANCE_D, 
  ELEMENTARY_CHARGE_E, 
  DIVISION_TO_METERS,
  calculateRadius,
  calculateChargeDynamic
} from "./physics";

export default function App() {
  // Simulator configuration states
  const [voltage, setVoltage] = useState<number>(200);
  const [voltageEnabled, setVoltageEnabled] = useState<boolean>(true);
  const [polarity, setPolarity] = useState<"normal" | "reverse">("normal");
  const [focusLevel, setFocusLevel] = useState<number>(35);
  const [squeezeCount, setSqueezeCount] = useState<number>(0);
  const [scaleSDivs, setScaleSDivs] = useState<number>(5);

  // Droplets state
  const [droplets, setDroplets] = useState<Droplet[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  // Staging area for active droplet measurement log
  const [stagingUf, setStagingUf] = useState<number | null>(null);
  const [stagingT1, setStagingT1] = useState<number | null>(null);
  const [stagingT2, setStagingT2] = useState<number | null>(null);

  // Overall logs and notification triggers
  const [logs, setLogs] = useState<LabLog[]>([]);
  const [notification, setNotification] = useState<{ text: string; type: "info" | "success" | "warning" } | null>({
    text: "دستگاه شبیه‌ساز میلیکان آماده به کار است. ولتاژ روی ۲۰۰ ولت تنظیم شده. پمپ لاستیکی را بار اول فشار دهید تا آزمایش آغاز شود.",
    type: "info"
  });

  const lastFrameTimeRef = useRef<number>(Date.now());
  const dropletIdCounter = useRef<number>(101);

  // Auto-dismiss notification after 6 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Squeeze the rubber bulb to generate 15-20 random oil droplets inside the chamber
  const handleSqueezeBulb = () => {
    const isFirstTime = squeezeCount === 0;
    const count = Math.floor(Math.random() * 6) + 14; // 14 to 19 droplets
    const newDrops: Droplet[] = [];

    for (let i = 0; i < count; i++) {
      const id = dropletIdCounter.current++;
      
      // Randomize radii in meters (typical 0.75e-6 to 2.1e-6)
      const radius = (0.75 + Math.random() * 1.35) * 1e-6;
      
      // Elementary charges count (typical 2 to 9 electrons)
      const n = Math.floor(Math.random() * 8) + 2; 
      
      // 80% negative, 15% positive, 5% neutral
      const roll = Math.random();
      const chargeSign = roll < 0.80 ? -1 : roll < 0.95 ? 1 : 0;
      const charge = n * chargeSign * ELEMENTARY_CHARGE_E;

      // Depth z ranges from 0 to 100 for visual focus simulation
      const z = Math.floor(Math.random() * 101);

      // Random starting coordinates
      // Microscope view maps physical Y from 0.25mm to 1.25mm. Let's start around the top/middle chamber.
      const y = 0.65 + Math.random() * 0.55; // 0.65mm to 1.2 mm
      const x = 0.2 + Math.random() * 0.6; // center horizontally mostly

      // Brownian/thermal slight drift values
      const driftX = (Math.random() - 0.5) * 0.012; // slow drift
      const driftY = (Math.random() - 0.5) * 0.006;

      newDrops.push({
        id,
        x,
        y,
        z,
        radius,
        charge,
        n,
        chargeSign,
        driftX,
        driftY
      });
    }

    setDroplets((prev) => [...prev, ...newDrops]);
    setSqueezeCount((prev) => prev + 1);

    if (isFirstTime) {
      setNotification({
        text: "ابر قطرات روغن با موفقیت پاشیده شد! با پیچ کانون‌ساز تصویر را شفاف کنید تا ذرات درخشان پدیدار شوند.",
        type: "success"
      });
    } else {
      setNotification({
        text: "پمپاژ انجام شد. توجه داشته باشید فشرده‌سازی چندباره بالون باعث پراکندگی بارهای الکترواستاتیکی و خطای همسایگی در محاسبه می‌شود.",
        type: "warning"
      });
    }
  };

  // Clear Chamber (Precipitate all droplets)
  const handleClearChamber = () => {
    setDroplets([]);
    setSelectedId(null);
    setSqueezeCount(0);
    setStagingUf(null);
    setStagingT1(null);
    setStagingT2(null);
    setNotification({
      text: "اتاقک خازن تحت تخلیه قرار گرفت. تمامی قطرات روغن رسوب نموده و محفظه آماده پاشش مجدد است.",
      type: "info"
    });
  };

  // Pre-seed beautiful completed experimental data
  const handlePreseedLogs = () => {
    // 4 sample logs showing beautiful quantization around 1.6e-19 C
    const sampleLogs: LabLog[] = [
      {
        id: "seed_1",
        dropletId: 104,
        n: 4,
        r: 1.05e-6,
        uF: 236,
        u2: 380,
        sDivs: 5,
        t1: 5.15,
        t2: 3.98,
        v1: (5 * DIVISION_TO_METERS) / 5.15,
        v2: (5 * DIVISION_TO_METERS) / 3.98,
        qCalculated: 6.46e-19,
        errorPercent: 0.82
      },
      {
        id: "seed_2",
        dropletId: 109,
        n: 3,
        r: 0.92e-6,
        uF: 278,
        u2: 420,
        sDivs: 5,
        t1: 6.72,
        t2: 4.88,
        v1: (5 * DIVISION_TO_METERS) / 6.72,
        v2: (5 * DIVISION_TO_METERS) / 4.88,
        qCalculated: 4.75e-19,
        errorPercent: 1.25
      },
      {
        id: "seed_3",
        dropletId: 115,
        n: 6,
        r: 1.24e-6,
        uF: 195,
        u2: 350,
        sDivs: 5,
        t1: 3.70,
        t2: 2.52,
        v1: (5 * DIVISION_TO_METERS) / 3.70,
        v2: (5 * DIVISION_TO_METERS) / 2.52,
        qCalculated: 9.71e-19,
        errorPercent: 1.01
      },
      {
        id: "seed_4",
        dropletId: 122,
        n: 5,
        r: 1.12e-6,
        uF: 218,
        u2: 400,
        sDivs: 5,
        t1: 4.54,
        t2: 3.12,
        v1: (5 * DIVISION_TO_METERS) / 4.54,
        v2: (5 * DIVISION_TO_METERS) / 3.12,
        qCalculated: 8.09e-19,
        errorPercent: 0.98
      }
    ];

    setLogs(sampleLogs);
    setNotification({
      text: "داده‌های مرجع آزمایشگاهی به صورت کامل بارگذاری شدند. به همگرایی بارهای تک‌الکترونی تجربی به عدد ۱.۶e-۱۹ دقت کنید.",
      type: "success"
    });
  };

  // Main physical simulation frame ticker
  useEffect(() => {
    let animationId: number;

    const tick = () => {
      const now = Date.now();
      const dt = Math.min(0.1, (now - lastFrameTimeRef.current) / 1000); // delta-time in seconds
      lastFrameTimeRef.current = now;

      // Electric field E in V/m: E = V / d if enabled
      const eVoltage = voltageEnabled ? voltage : 0;
      const eFieldMagnitude = eVoltage / PLATE_DISTANCE_D; 
      
      // Field direction depends on polarity
      // normal: points downward (gravitational force negative direction) -> E_vector = -E
      // reverse: points upward -> E_vector = +E
      const electricFieldVector = polarity === "normal" ? -eFieldMagnitude : eFieldMagnitude;

      setDroplets((prevDroplets) => {
        const updated: Droplet[] = [];

        for (const drop of prevDroplets) {
          // 1. Calculate physical weight force (acting downwards -> negative Y)
          // F_grav_eff = - (4/3) * pi * r^3 * (rho_oil - rho_air) * g
          const massEff = (4 / 3) * Math.PI * Math.pow(drop.radius, 3) * (RHO_OIL - RHO_AIR);
          const fWeight = -massEff * G_GRAVITY;

          // 2. Calculate electric force
          // F_elec = q * E_vector
          // If droplet is negatively charged (q < 0) and normal polarity (E_vector < 0), F_elec is positive (UP)
          const fElec = drop.charge * electricFieldVector;

          // 3. Due to instant terminal velocity, drag force matches remaining forces:
          // F_net = F_weight + F_elec + F_drag = 0  ==>  F_drag = - (F_weight + F_elec)
          // 6 * pi * eta * r * v = F_weight + F_elec
          // v = (F_weight + F_elec) / (6 * pi * eta * r)
          const stokesDenominator = 6 * Math.PI * ETA_AIR * drop.radius;
          const vPhysical = (fWeight + fElec) / stokesDenominator; // speed in meters per second

          // 4. Update coordinates (y is vertical in physical mm)
          // y = y + v * dt * 1000 (conversion to mm)
          const yNew = drop.y + vPhysical * dt * 1000;
          let xNew = drop.x + drop.driftX * dt;

          // Constrain x bounds
          if (xNew < 0.0) xNew = 0.0;
          if (xNew > 1.0) xNew = 1.0;

          // Check boundary plates collision
          // If y goes out of bounds (bottom plate = 0.0, top plate = d = 1.6 mm), it gets extinguished
          if (yNew >= 0.0 && yNew <= 1.6) {
            updated.push({
              ...drop,
              x: xNew,
              y: yNew,
            });
          } else {
            // Selected droplet crashed/extinguished
            if (drop.id === selectedId) {
              setSelectedId(null);
              setNotification({
                text: `قطره معلق #${drop.id} به بازه صفحات برخورد کرده و تخلیه شد. لطفاً قطره دیگری انتخاب کنید.`,
                type: "warning"
              });
            }
          }
        }

        return updated;
      });

      animationId = requestAnimationFrame(tick);
    };

    animationId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationId);
  }, [voltage, voltageEnabled, polarity, selectedId]);

  // Handle stopwatch time transfer callback
  const handleTransferTime = (timeSeconds: number, target: "t1" | "t2") => {
    if (selectedId === null) {
      setNotification({
        text: "هیچ قطره‌ای برای انتساب فعال نیست. ابتدا یک ذره را در عینک میکروسکوپ کلیک کرده و مشخص سازید.",
        type: "warning"
      });
      return;
    }

    if (target === "t1") {
      setStagingT1(timeSeconds);
      setNotification({
        text: `زمان سقوط ته‌نشینی t₁ برابر با ${timeSeconds} ثانیه برای ذره #${selectedId} پین شد.`,
        type: "success"
      });
    } else {
      setStagingT2(timeSeconds);
      setNotification({
        text: `زمان صعود اجباری t₂ برابر با ${timeSeconds} ثانیه برای ذره #${selectedId} پین شد.`,
        type: "success"
      });
    }
  };

  // Set the current running voltage as the suspension voltage U_f
  const handleCaptureUf = () => {
    if (selectedId === null) {
      setNotification({
        text: "لطفاً ابتدا روی یک ذره معلق کلیک کرده و سپس ولتاژ تعلیق آن را ثبت کنید.",
        type: "warning"
      });
      return;
    }
    
    if (!voltageEnabled || voltage < 100 || voltage > 300) {
      setNotification({
        text: "ولتاژ تعلیق انتخابی نامعتبر یا دور افتاده است! طبق پروتکل، ولتاژ تراز تعلیق U_f باید مایند ۱۰۰ الی ۳۰۰ ولت باشد.",
        type: "warning"
      });
      return;
    }

    setStagingUf(voltage);
    setNotification({
      text: `ولتاژ تعليق ترجیحی (U_f) برابر با ${voltage.toFixed(0)} ولت برای ذره #${selectedId} ثبت شد.`,
      type: "success"
    });
  };

  // Perform calculations and commit staging values to Log notebook
  const handleCommitRow = () => {
    if (selectedId === null || stagingT1 === null || stagingT2 === null || stagingUf === null) {
      setNotification({
        text: "اطلاعات ثبت شده ناقص است! باید هر سه مؤلفه: ولتاژ تعلیق (Uf)، زمان سقوط (t1) و زمان صعود (t2) کامل باشند.",
        type: "warning"
      });
      return;
    }

    // Lookup original physics properties of the selected droplet to maintain integrity, but added visual scale error!
    const activeDrop = droplets.find((d) => d.id === selectedId);
    if (!activeDrop) {
      setNotification({
        text: "ذره انتخاب شده یافت نشد یا سقوط کرده است.",
        type: "warning"
      });
      return;
    }

    // Physical calculations using formulas
    const v1 = (scaleSDivs * DIVISION_TO_METERS) / stagingT1;
    const v2 = (scaleSDivs * DIVISION_TO_METERS) / stagingT2;
    
    // Calculate radius and charge with added human laboratory observational error
    // If they squeezed the balloon multiple times, visual interference introduces up to 8% error
    const squeezeErrorFactor = squeezeCount <= 1 ? 1.0 : (1.0 + (Math.random() - 0.5) * 0.08 * (squeezeCount - 1));
    const timerReactionError = 1.0 + (Math.random() - 0.5) * 0.04; // ±2% timer delay bias

    const rCalculated = calculateRadius(v1) * timerReactionError;
    // Current testing dynamic voltage (U2 is what is used for lifting, which is what we staged during t2 measurements.
    // If current voltage is set, we take the current voltage or approximate a reasonable U2 as 2 * Uf or active value)
    const runningU2 = voltageEnabled && voltage > stagingUf ? voltage : stagingUf * 1.6;

    const rawQ = calculateChargeDynamic(runningU2, rCalculated, v1, v2) * squeezeErrorFactor * timerReactionError;
    
    // Round to nearest multiple of elementary charge e
    const estimatedN = Math.max(1, Math.round(rawQ / ELEMENTARY_CHARGE_E));
    const eExperimental = rawQ / estimatedN;
    const deviationPercent = Math.abs((eExperimental - ELEMENTARY_CHARGE_E) / ELEMENTARY_CHARGE_E) * 100;

    const newLog: LabLog = {
      id: "log_" + Date.now(),
      dropletId: selectedId,
      n: estimatedN,
      r: rCalculated,
      uF: stagingUf,
      u2: runningU2,
      sDivs: scaleSDivs,
      t1: stagingT1,
      t2: stagingT2,
      v1,
      v2,
      qCalculated: rawQ,
      errorPercent: deviationPercent
    };

    setLogs((prev) => [newLog, ...prev]);

    // Reset staging values
    setStagingUf(null);
    setStagingT1(null);
    setStagingT2(null);

    setNotification({
      text: `ردیف محاسباتی پیرامون ذره #${selectedId} با بار الکتریکی محاسبه شده ${(rawQ * 1e19).toFixed(3)}e-19 C به صورت کامل ثبت شد.`,
      type: "success"
    });
  };

  const selectedDroplet = droplets.find((d) => d.id === selectedId);

  return (
    <div id="main-app" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      
      {/* Visual Header / Laboratory Masthead */}
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4.5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20 text-amber-400 animate-spin" style={{ animationDuration: "12s" }}>
              <Atom className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-slate-100 flex items-center gap-2">
                دستگاه شبیه‌ساز فیزیک ذرات میلیکان
                <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded-full">تعاملی پیشرفته</span>
              </h1>
              <p className="text-xs text-slate-400">
                پرتکل کالیبراسیون و سنجش کوانتش بار الکتریکی الکترون ($q = n \cdot e$) همراه با خطای آزمایشگاهی واقعی
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-slate-500 text-xs hidden md:inline font-mono">STATUS: HIGH_VACUUM_CHAMBER_ON</span>
            <div className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 text-xs font-mono font-bold flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-emerald-400 shrink-0" />
              e = ۱.۶۰۲e-۱۹ C
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Dashboard */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 flex flex-col gap-6">
        
        {/* Dynamic Notification Banner */}
        {notification && (
          <div 
            id="notification-banner"
            className={`border rounded-xl p-3.5 flex items-start gap-3 transition-opacity duration-300 shadow-md ${
              notification.type === "success" 
                ? "bg-emerald-950/80 border-emerald-800 text-emerald-200" 
                : notification.type === "warning"
                  ? "bg-red-950/80 border-red-800 text-red-200"
                  : "bg-slate-900/90 border-slate-800 text-slate-200"
            }`}
          >
            <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${
              notification.type === "success" ? "text-emerald-400" : notification.type === "warning" ? "text-red-400" : "text-amber-500"
            }`} />
            <div className="text-xs font-medium leading-relaxed font-sans">{notification.text}</div>
          </div>
        )}

        {/* WORKSPACE DIVIDED LAYOUT */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT WING: Realtime eyepiece viewport, Stopwatch, and Staging Area (5 Columns) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* 1. Realtime Eyepiece */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6.5 shadow-xl flex flex-col items-center justify-center">
              <div className="w-full flex justify-between items-center mb-4">
                <span className="text-xs text-slate-300 font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  میدان دید تاریک میکروسکوپ نوری
                </span>
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded font-mono">
                  <span>ذرات معلق:</span>
                  <strong className="text-amber-400">{droplets.length}</strong>
                </div>
              </div>
              
              <MicroscopeView
                droplets={droplets}
                selectedId={selectedId}
                focusLevel={focusLevel}
                onSelectDroplet={(id) => {
                  setSelectedId(id);
                  // Reset staging for clean slate
                  setStagingUf(null);
                  setStagingT1(null);
                  setStagingT2(null);
                  setNotification({
                    text: `ذره باردار #${id} با موفقیت در کانون ردیابی شد. اکنون با تغییر ولتاژ آن را معلق کنید.`,
                    type: "info"
                  });
                }}
                scaleSDivs={scaleSDivs}
              />
            </div>

            {/* 2. Staging and calibration dashboard */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col gap-4">
              <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5 border-b border-slate-800 pb-2">
                <Award className="w-4 h-4 text-amber-500" />
                کنترل پنل ردیابی ذره فعال
              </h4>

              {selectedDroplet ? (
                <div className="flex flex-col gap-3 font-sans">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    {/* Balanced Uf Block */}
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-[9px] text-slate-500 block mb-1">ولتاژ تعلیق (Uf)</span>
                      {stagingUf !== null ? (
                        <span className="text-sm font-mono text-emerald-400 font-bold">{stagingUf}V</span>
                      ) : (
                        <button
                          onClick={handleCaptureUf}
                          className="w-full bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 py-1 rounded text-[10px] cursor-pointer font-bold"
                        >
                          ثبت U_f فعلی
                        </button>
                      )}
                    </div>

                    {/* Time T1 Block */}
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-850">
                      <span className="text-[9px] text-slate-500 block mb-1">زمان سقوط t₁</span>
                      <span className={`text-sm font-mono font-bold block ${stagingT1 !== null ? 'text-blue-300' : 'text-slate-600'}`}>
                        {stagingT1 !== null ? `${stagingT1.toFixed(2)}s` : "---"}
                      </span>
                    </div>

                    {/* Time T2 Block */}
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-850">
                      <span className="text-[9px] text-slate-500 block mb-1">زمان صعود t₂</span>
                      <span className={`text-sm font-mono font-bold block ${stagingT2 !== null ? 'text-emerald-300' : 'text-slate-600'}`}>
                        {stagingT2 !== null ? `${stagingT2.toFixed(2)}s` : "---"}
                      </span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800 text-[10.5px]">
                    <span className="text-slate-400">مسافت گام حرکت الکترون (S):</span>
                    <div className="flex items-center gap-1.5 font-mono text-white">
                      <button 
                        onClick={() => setScaleSDivs(Math.max(1, scaleSDivs - 1))}
                        className="w-5 h-5 bg-slate-800 hover:bg-slate-700 rounded flex items-center justify-center text-xs cursor-pointer"
                      >
                        -
                      </button>
                      <strong className="text-amber-400 px-1 font-bold">{scaleSDivs}</strong>
                      <button 
                        onClick={() => setScaleSDivs(Math.min(9, scaleSDivs + 1))}
                        className="w-5 h-5 bg-slate-800 hover:bg-slate-700 rounded flex items-center justify-center text-xs cursor-pointer"
                      >
                        +
                      </button>
                      <span className="text-[9px] text-slate-500">واحد بزرگ مدرج</span>
                    </div>
                  </div>

                  {/* Commit final Row Button */}
                  <button
                    disabled={stagingUf === null || stagingT1 === null || stagingT2 === null}
                    onClick={handleCommitRow}
                    className="w-full flex items-center justify-center gap-1.5 bg-linear-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-600 py-2 rounded-lg font-black text-xs cursor-pointer select-none border border-amber-600/20 disabled:pointer-events-none transition-all"
                  >
                    <PlusCircle className="w-4 h-4 shrink-0" />
                    ذخیره ردیف نهایی و تحلیل ذرات در جدول محاسبات
                  </button>
                </div>
              ) : (
                <div className="text-center p-4 bg-slate-950/40 rounded-lg border border-dashed border-slate-800 text-xs text-slate-500 leading-relaxed font-sans">
                  برای انجام محاسبات تعلیق، <strong className="text-amber-500/80">یک قطره نوری فعال را در میکروسکوپ انتخاب کنید</strong> تا پنل هماهنگ‌ساز ردیابی فعال شود.
                </div>
              )}
            </div>

            {/* 3. High Precision Stopwatch */}
            <Stopwatch 
              onTransferTime={handleTransferTime} 
              selectedDropletId={selectedId}
            />

          </div>

          {/* RIGHT WING: Command Console, Parameter Switches, and Protocol Steps Checkbox (7 Columns) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            
            {/* Hardware Console Controls */}
            <Controls
              voltage={voltage}
              setVoltage={setVoltage}
              voltageEnabled={voltageEnabled}
              setVoltageEnabled={setVoltageEnabled}
              polarity={polarity}
              setPolarity={setPolarity}
              focusLevel={focusLevel}
              setFocusLevel={setFocusLevel}
              onSqueezeBulb={handleSqueezeBulb}
              squeezeCount={squeezeCount}
              onClearChamber={handleClearChamber}
            />

            {/* Notebook view tables combined */}
            <DataNotebook
              logs={logs}
              onAddLog={(newLog) => setLogs((prev) => [newLog, ...prev])}
              onDeleteLog={(id) => setLogs((prev) => prev.filter((log) => log.id !== id))}
              onClearLogs={() => setLogs([])}
              onPreseedLogs={handlePreseedLogs}
              selectedDropletId={selectedId}
              currentUf={voltage}
            />
          </div>
        </div>

        {/* Informational footer credits */}
        <footer className="mt-8 border-t border-slate-800/60 pt-4 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] text-slate-500">
          <p className="font-sans">
            طراحی شده بر اساس متد استاندارد ردیابی فوتوالکتریک روغن میلیکان. استفاده از تمام توانمندی‌های لنز کانون‌ساز نوری و کرونومتر دیجیتال.
          </p>
          <div className="flex gap-4 font-mono">
            <span>VISCOSITY_CONSTANT: 1.81e-5 Pa·s</span>
            <span>CHAMBER_SPACING: 1.6 mm</span>
          </div>
        </footer>

      </main>
    </div>
  );
}
